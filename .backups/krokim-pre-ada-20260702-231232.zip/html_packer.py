import base64
import html
import mimetypes
import re
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox
from urllib.parse import unquote, urlsplit


def read_text_file(path: Path) -> str:
    """
    Dosyayı farklı olası karakter kodlamalarıyla okumayı dener.
    Türkçe karakter sorunu yaşamamak için birkaç encoding sırayla denenir.
    """
    encodings = ["utf-8", "utf-8-sig", "cp1254", "latin-1"]
    last_error = None

    for enc in encodings:
        try:
            return path.read_text(encoding=enc)
        except Exception as e:
            last_error = e

    raise RuntimeError(f"Dosya okunamadı: {path}\nSon hata: {last_error}")


def escape_script_content(js_text: str) -> str:
    """
    JS içinde </script> geçerse HTML script bloğunu erken kapatmasın diye kaçırır.
    """
    return re.sub(r"</script", "<\\/script", js_text, flags=re.IGNORECASE)


def escape_style_content(css_text: str) -> str:
    """
    CSS icinde </style> gecerse HTML style blogunu erken kapatmasin diye kacirir.
    """
    return re.sub(r"</style", "<\\/style", css_text, flags=re.IGNORECASE)


def escape_attr(value: str) -> str:
    """
    HTML attribute içine güvenli yazmak için kullanılır.
    Örneğin data-packed-source="..." içinde tırnak vb. sorun çıkarmasın.
    """
    return html.escape(value, quote=True)


def is_external_ref(ref: str) -> bool:
    """
    data:, blob:, http(s):, //cdn ve #fragment gibi tek dosyada gomulmemesi
    gereken referanslari ayirir.
    """
    value = (ref or "").strip()
    return (
        not value
        or value.startswith("#")
        or value.startswith("//")
        or re.match(r"^[a-zA-Z][a-zA-Z0-9+.-]*:", value) is not None
    )


def local_ref_path(ref: str) -> str:
    """
    src/home.css?v=123 gibi tarayici URL'lerinden dosya yolunu ayiklar.
    Dosya ararken query/hash kullanilmaz.
    """
    parts = urlsplit((ref or "").strip())
    return unquote(parts.path)


def resolve_local_ref(base_dir: Path, ref: str) -> Path:
    return (base_dir / local_ref_path(ref)).resolve()


def mime_type_for(path: Path) -> str:
    return mimetypes.guess_type(path.name)[0] or "application/octet-stream"


def inline_css_urls(css_text: str, css_base_dir: Path) -> str:
    """
    CSS icindeki url(...) referanslarini data URL olarak gomerek font/gorsel
    bagimliligini de tek HTML icine alir.
    """
    css_url_pattern = re.compile(
        r"url\(\s*([\"']?)(.*?)\1\s*\)",
        re.IGNORECASE | re.DOTALL
    )

    def replace_url(match: re.Match) -> str:
        ref = (match.group(2) or "").strip()

        if is_external_ref(ref):
            return match.group(0)

        asset_path = resolve_local_ref(css_base_dir, ref)

        if not asset_path.exists():
            print(f"[UYARI] CSS url dosyasi bulunamadi: {ref}")
            return match.group(0)

        encoded = base64.b64encode(asset_path.read_bytes()).decode("ascii")
        return f'url("data:{mime_type_for(asset_path)};base64,{encoded}")'

    return css_url_pattern.sub(replace_url, css_text)


def inline_css(html_text: str, base_dir: Path) -> str:
    """
    index.html içindeki yerel CSS linklerini bulur,
    dosya içeriğini <style> içine gömer.
    Ayrıca başlangıç/bitiş açıklamaları ekler.
    """
    css_link_pattern = re.compile(
        r'<link\b(?=[^>]*\brel\s*=\s*["\']stylesheet["\'])([^>]*?)\bhref\s*=\s*["\']([^"\']+)["\']([^>]*?)>',
        re.IGNORECASE | re.DOTALL
    )

    def replace_link(match: re.Match) -> str:
        href = match.group(2).strip()

        # Harici CSS dosyalarını gömme
        if is_external_ref(href):
            print(f"[UYARI] Harici CSS atlandı: {href}")
            return match.group(0)

        css_path = resolve_local_ref(base_dir, href)

        if not css_path.exists():
            print(f"[UYARI] CSS dosyası bulunamadı: {href}")
            return match.group(0)

        css_text = read_text_file(css_path)
        css_text = inline_css_urls(css_text, css_path.parent)
        css_text = escape_style_content(css_text)
        safe_href = escape_attr(href)

        print(f"[OK] CSS gömüldü: {href}")

        return (
            f"<!-- PACKED BEGIN CSS: {href} -->\n"
            f"<style data-packed-source=\"{safe_href}\">\n"
            f"/* PACKED SOURCE: {href} */\n"
            f"{css_text}\n"
            f"/* PACKED END SOURCE: {href} */\n"
            f"</style>\n"
            f"<!-- PACKED END CSS: {href} -->"
        )

    return css_link_pattern.sub(replace_link, html_text)


def inline_js(html_text: str, base_dir: Path) -> str:
    """
    index.html içindeki yerel JS script src bağlantılarını bulur,
    dosya içeriğini doğrudan <script> içine gömer.
    Ayrıca başlangıç/bitiş açıklamaları ekler.
    """
    script_src_pattern = re.compile(
        r'<script\b([^>]*?)\bsrc\s*=\s*["\']([^"\']+)["\']([^>]*)>\s*</script>',
        re.IGNORECASE | re.DOTALL
    )

    def replace_script(match: re.Match) -> str:
        before_attrs = match.group(1) or ""
        src = match.group(2).strip()
        after_attrs = match.group(3) or ""

        # Harici JS dosyalarını gömme
        if is_external_ref(src):
            print(f"[UYARI] Harici JS atlandı: {src}")
            return match.group(0)

        js_path = resolve_local_ref(base_dir, src)

        if not js_path.exists():
            print(f"[UYARI] JS dosyası bulunamadı: {src}")
            return match.group(0)

        js_text = read_text_file(js_path)
        js_text = escape_script_content(js_text)

        safe_src = escape_attr(src)

        print(f"[OK] JS gömüldü: {src}")

        # src dışındaki mevcut script attribute'larını korur.
        # Örn: type="module" gibi attribute'lar kaybolmaz.
        combined_attrs = f"{before_attrs} {after_attrs}".strip()
        combined_attrs = re.sub(r"\s+", " ", combined_attrs).strip()

        attrs_part = f" {combined_attrs}" if combined_attrs else ""

        return (
            f"<!-- PACKED BEGIN JS: {src} -->\n"
            f"<script{attrs_part} data-packed-source=\"{safe_src}\">\n"
            f"/* PACKED SOURCE: {src} */\n"
            f"{js_text}\n"
            f"/* PACKED END SOURCE: {src} */\n"
            f"</script>\n"
            f"<!-- PACKED END JS: {src} -->"
        )

    return script_src_pattern.sub(replace_script, html_text)


def pack_project_folder(folder_path: Path) -> Path:
    """
    Seçilen klasördeki index.html dosyasını okur.
    Yerel CSS ve JS dosyalarını içine gömer.
    Sonucu packed.html olarak aynı klasöre yazar.
    """
    html_path = folder_path / "index.html"

    if not html_path.exists():
        raise FileNotFoundError(f"Seçilen klasörde index.html bulunamadı:\n{folder_path}")

    html_text = read_text_file(html_path)

    html_text = inline_css(html_text, folder_path)
    html_text = inline_js(html_text, folder_path)

    output_path = folder_path / "packed.html"
    output_path.write_text(html_text, encoding="utf-8")

    return output_path


def choose_folder():
    """
    Kullanıcıdan HTML projesinin bulunduğu klasörü seçmesini ister.
    """
    root = tk.Tk()
    root.withdraw()
    root.attributes("-topmost", True)

    folder = filedialog.askdirectory(title="HTML projesinin bulunduğu klasörü seç")

    root.destroy()

    if not folder:
        return None

    return Path(folder)


def show_info(title: str, message: str):
    """
    Bilgi mesajı gösterir.
    """
    root = tk.Tk()
    root.withdraw()
    root.attributes("-topmost", True)

    messagebox.showinfo(title, message)

    root.destroy()


def show_error(title: str, message: str):
    """
    Hata mesajı gösterir.
    """
    root = tk.Tk()
    root.withdraw()
    root.attributes("-topmost", True)

    messagebox.showerror(title, message)

    root.destroy()


def main():
    try:
        folder_path = choose_folder()

        if folder_path is None:
            print("Klasör seçilmedi. İşlem iptal edildi.")
            return

        output_path = pack_project_folder(folder_path)

        print(f"\n[TAMAM] Tek parça HTML üretildi:\n{output_path}")

        show_info(
            "İşlem tamam",
            f"Tek parça HTML oluşturuldu:\n{output_path}"
        )

    except Exception as e:
        print(f"[HATA] {e}")
        show_error("Hata", str(e))


if __name__ == "__main__":
    main()
